package com.example.demosoundbox

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val purple = Color.rgb(95, 37, 159)
    private val dark = Color.rgb(39, 25, 54)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var content: LinearLayout
    private lateinit var amountInput: EditText
    private lateinit var languageSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        showHome()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale("en", "IN")
        }
    }

    private fun baseScreen(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 245, 252))
            setPadding(22, 22, 22, 22)
        }
        val header = TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(purple)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 72))
        val warning = TextView(this).apply {
            text = "DEMO ONLY • NOT A REAL PAYMENT"
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(125, 35, 35))
            gravity = Gravity.CENTER
            setPadding(8, 12, 8, 12)
            setBackgroundColor(Color.rgb(255, 226, 226))
        }
        root.addView(warning)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 20, 0, 0)
        }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addText(text: String, size: Float = 16f, bold: Boolean = false) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(dark)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(4, 10, 4, 10)
        })
    }

    private fun addButton(text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener { action() }
        }
        content.addView(b, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, 7, 0, 7)
        })
    }

    private fun showHome() {
        baseScreen("Demo Soundbox")
        addText("Spoken demo payment announcement", 18f, true)
        addText("Enter an amount and tap Announce. The phone speaker will speak a demo message. No money is received or transferred.")
        amountInput = EditText(this).apply {
            hint = "Enter amount in rupees (e.g. 500)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 20f
            setSingleLine(true)
        }
        content.addView(amountInput, LinearLayout.LayoutParams(-1, 58))

        addText("Announcement language", 15f, true)
        languageSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("English", "Hindi")
            )
        }
        content.addView(languageSpinner, LinearLayout.LayoutParams(-1, 52))

        addButton("🔊 Announce Demo Payment") { announceAmount() }
        addButton("Test Soundbox Voice") {
            speak(if (languageSpinner.selectedItemPosition == 1)
                "Yeh sirf demo hai. Koi asli payment nahi hui hai."
            else
                "This is a demo only. No real payment was made.",
                languageSpinner.selectedItemPosition == 1)
        }
        addText("Unofficial entertainment app. Not affiliated with PhonePe.", 13f)
        addText("If voice is silent, install or enable a Text-to-Speech voice in Android Settings.")
    }

    private fun announceAmount() {
        val raw = amountInput.text.toString().trim()
        if (raw.isEmpty()) {
            Toast.makeText(this, "Please enter a demo amount", Toast.LENGTH_SHORT).show()
            return
        }
        val value = raw.toDoubleOrNull()
        if (value == null || value < 0 || value > 10000000) {
            Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }
        val amountText = if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
        val hindi = languageSpinner.selectedItemPosition == 1
        val spoken = if (hindi) {
            "Demo payment. Rupees $amountText received. Yeh asli payment nahi hai."
        } else {
            "Demo payment. Rupees $amountText received. This is not a real payment."
        }
        speak(spoken, hindi)
        Toast.makeText(this, "DEMO announcement only — no payment received", Toast.LENGTH_LONG).show()
    }

    private fun speak(message: String, hindi: Boolean) {
        if (!ttsReady) {
            Toast.makeText(this, "Text-to-Speech is starting. Try again in a moment.", Toast.LENGTH_LONG).show()
            return
        }
        val locale = if (hindi) Locale("hi", "IN") else Locale("en", "IN")
        val result = tts?.setLanguage(locale) ?: TextToSpeech.ERROR
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(this, "Selected voice is not installed. Install it in Android Text-to-Speech settings.", Toast.LENGTH_LONG).show()
            return
        }
        tts?.setSpeechRate(0.92f)
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "demo_soundbox_announcement")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
