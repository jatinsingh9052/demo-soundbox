Demo Soundbox Android project
=============================

Entertainment-only Android soundbox simulator using Android Text-to-Speech.
It speaks a user-entered amount and always states that it is a demo / not a real payment.
It is unofficial and not affiliated with PhonePe. No network, UPI, bank, or payment integration is included.

Build an installable APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open and select the DemoSoundboxAndroid folder.
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK is usually at app/build/outputs/apk/debug/app-debug.apk.
7. Transfer it to your Android phone and install it. If asked, allow installs from that file manager.

Voice:
- Uses Android TextToSpeech and needs a compatible voice installed on the phone.
- English and Hindi are offered; if a voice is missing, install voice data from Android Settings > Text-to-speech output.

Build using only your Android phone (cloud build):
1. Download and extract this ZIP using a file manager that supports ZIP extraction.
2. Create a new repository on GitHub in your phone browser.
3. Upload the extracted project files and folders to the repository. Make sure .github/workflows/build.yml is included.
4. Open the repository's Actions tab, choose "Build Demo Soundbox APK", and tap Run workflow (or wait for the first push build).
5. When the run finishes successfully, open the run and download the "DemoSoundbox-debug-apk" artifact.
6. Extract the downloaded artifact ZIP; install app-debug.apk. Android may ask you to allow installs from your browser/file manager.

This uses GitHub's cloud build runner; it does not compile on the phone itself. GitHub account and internet access are required.
